package com.example.pr15

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.webkit.WebView.FindListener
import android.widget.Button
import android.widget.TextView
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    private lateinit var trueB:Button
    private lateinit var falseB:Button
    private lateinit var nextB:Button
    private lateinit var prevB:Button
    private lateinit var questText:TextView
    private var Index=0

    private val qustback= listOf(
        Question(R.string.quest1,true),
        Question(R.string.quest2,true),
        Question(R.string.quest3,false),
        Question(R.string.quest4,true),
        Question(R.string.quest5,false),
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        trueB=findViewById(R.id.btrue)
        falseB=findViewById(R.id.bfal)
        nextB=findViewById(R.id.bnex)
        prevB=findViewById(R.id.bprev)
        questText=findViewById(R.id.text)
        trueB.setOnClickListener { view:View ->
            Toast.LENGTH_SHORT
            check(true)
        }
        falseB.setOnClickListener { view:View ->
            Toast.LENGTH_SHORT
            check(false)
        }
        nextB.setOnClickListener{
            Index=(Index+1) % qustback.size
            Update()
        }
        prevB.setOnClickListener{
            if (Index-1<0)
            {
                Index=qustback.size-1
                Update()
            }
            else
            {
                Index=Index-1
                Update()
            }
        }
        Update()

    }
    private fun Update(){
        val questtextid=qustback[Index].textResId
        questText.setText(questtextid)
    }
    private fun check(Answer:Boolean){
        val corrAnswer=qustback[Index].answer
        val message=if(Answer==corrAnswer){
            R.string.corr
        }
        else
        {
            R.string.incorr
        }
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show()
    }
}